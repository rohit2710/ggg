package com.grievance.entity;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum ComplaintStatus {
	PENDING,
	RESOLVED,
	REOPENED;
	 
	
}
