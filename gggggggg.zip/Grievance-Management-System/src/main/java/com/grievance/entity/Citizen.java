package com.grievance.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class Citizen {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "citizenid")
	private Integer citizenId;
	@Column(length = 30)
	private String name;
	@Column(length = 30, unique = true, nullable = false)
	private String email;
	@Column(nullable = false)
	private String password;
	private String role;
	@Column(name = "mobileno", length = 13)
	private String mobileNo;
	@Column(name = "aadharno", length = 15)
	private String aadharNo;
	@Column(name = "isactivated")
	private boolean isActived;
	@Column(name = "loginattempts")
	private Integer loginAttempts;
	@CreationTimestamp
	@Column(name = "createdat")
	private Instant createdAt;
	@Column(name = "lastlogin")
	private Instant lastLogin;

	public Citizen() {
		super();
	}

	public Citizen(String name, String email, String password, String role, String mobileNo, String aadharNo) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.role = role;
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
	}

	public Integer getCitizenId() {
		return citizenId;
	}

	public void setCitizenId(Integer citizenId) {
		this.citizenId = citizenId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	//old code
	public boolean isActived() {
		return isActived;
	}

	public void setActived(boolean isActived) {
		this.isActived = isActived;
	}

	public Integer getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Instant lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Override
	public String toString() {
		return "Citizen [citizenId=" + this.citizenId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", role=" + role + ", mobileNo=" + mobileNo + ", aadharNo=" + aadharNo + ", isActived=" + isActived
				+ ", loginAttempts=" + loginAttempts + ", createdAt=" + createdAt + ", lastLogin=" + lastLogin + "]";
	}
}