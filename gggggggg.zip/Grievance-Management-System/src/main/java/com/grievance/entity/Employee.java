package com.grievance.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.Instant;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employeeid")
	private Integer employeeId;
	private String name;
	@Column(nullable = false, unique = true)
	private String email;
	private String password;
	private String role;
	@Column(name = "mobileno", length = 13)
	private String mobileNo;
	@Column(name = "loginattempts")
	private Integer loginAttempts;
	@CreationTimestamp
	@Column(name = "createdat")
	private Instant createdAt;
	@Column(name = "lastlogin")
	private Instant lastLogin;
	@Column(name = "isactivated")
	private boolean isActived;

	@ManyToOne(fetch = FetchType.LAZY, optional = true,cascade= {CascadeType.ALL})
	@JoinColumn(name = "deptid", nullable = true, referencedColumnName = "departmentId")
	private Department department;

	public Employee() {
		super();
	}

	public Employee(String name, String email, String password, String role, String mobileNo) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.role = role;
		this.mobileNo = mobileNo;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Integer getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Instant lastLogin) {
		this.lastLogin = lastLogin;
	}

	public boolean isActived() {
		return isActived;
	}

	public void setActived(boolean isActived) {
		this.isActived = isActived;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", role=" + role + ", mobileNo=" + mobileNo + ", loginAttempts=" + loginAttempts + ", createdAt="
				+ createdAt + ", lastLogin=" + lastLogin + ", isActived=" + isActived + "]";
	}

}