package com.grievance.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class Auth {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "authid")
	private Integer authId;
	private Integer otp;
	@CreationTimestamp
	@Column(name = "createdat")
	private Instant createdAt;

	@OneToOne
	@JoinColumn(name = "citizenId", nullable = true)
	private Citizen citizen;
	
	@OneToOne
	@JoinColumn(name = "employeeId", nullable = true)
	private Employee employee;

	public Auth() {
		super();
	}

	public Auth(Integer otp) {
		super();
		this.otp = otp;
	}

	public Integer getAuthId() {
		return authId;
	}

	public void setAuthId(Integer authId) {
		this.authId = authId;
	}

	public Integer getOtp() {
		return otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Citizen getCitizen() {
		return citizen;
	}

	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}
	

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Auth [authId=" + authId + ", otp=" + otp + ", createdAt=" + createdAt + "]";
	}

}