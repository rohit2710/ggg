package com.grievance.exception;

import org.springframework.http.HttpStatus;

public class CitizenException extends RuntimeException{
	
	private HttpStatus httpStatus;
	private String path;

	 public CitizenException(String message, HttpStatus httpStatus, String path) {
		super(message);
		this.httpStatus = httpStatus;
		this.path = path;
	
	}
	 
	 public CitizenException(String message, HttpStatus httpStatus) {
		 super(message);
		 this.httpStatus = httpStatus;
	 }
	
	public CitizenException(String message) {
		super(message);
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	
}
