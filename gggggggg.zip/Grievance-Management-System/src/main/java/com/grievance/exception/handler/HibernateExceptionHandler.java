package com.grievance.exception.handler;

import java.util.Date;

import org.hibernate.PropertyValueException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class HibernateExceptionHandler {

	//	DataIntegrityViolationException
	@ExceptionHandler(value = { PropertyValueException.class })
	public ResponseEntity<?> handleDataIntegrityViolationException(PropertyValueException  e) {
		HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), "Field can   " + e.getLocalizedMessage(), "Dd");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
	}
	
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<?> handleDataIntegrityViolationException(DataIntegrityViolationException  e) {
		HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
		ErrorResponse errorResponse = new ErrorResponse(new Date(), httpStatus.value(), "email address already exist");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
	}
}
