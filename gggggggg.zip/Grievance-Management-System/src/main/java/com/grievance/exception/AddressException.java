package com.grievance.exception;

import org.springframework.http.HttpStatus;

public class AddressException extends RuntimeException {

	private HttpStatus httpStatus;
	private String path;

	public AddressException(String message, HttpStatus httpStatus, String path) {
		super(message);
		this.httpStatus = httpStatus;
		this.path = path;
	}

	public AddressException(String message, HttpStatus httpStatus) {
		super(message);
	}

	public AddressException(String message) {
		super(message);
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
