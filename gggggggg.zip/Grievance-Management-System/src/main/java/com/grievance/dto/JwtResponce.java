package com.grievance.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Transient;

public class JwtResponce {
	private Integer userId;
	private String name;
    private String email;
	private List<String> roles = new ArrayList<>();
	private String token;
	public JwtResponce() {
		super();
	}
	
	public JwtResponce(Integer userId, String name, String email, List<String> roles, String token) {
		super();
		this.userId = userId;
		this.name=name;
		this.email = email;
		this.roles = roles;
		this.token = token;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		return "JwtResponce [userId=" + userId + ", name=" + name + ", email=" + email + ", roles=" + roles + ", token="
				+ token + "]";
	}

	

}