package com.grievance.dto;

import java.util.List;

public class GraphDataDTO {
 
	private Long totalComplaint;
	private List<StatusData> statusData;
	
	
	public GraphDataDTO() {
		
	}
	public GraphDataDTO(Long totalComplaint, List<StatusData> statusData) {
		super();
		this.totalComplaint = totalComplaint;
		this.statusData = statusData;
	}
	public Long getTotalComplaint() {
		return totalComplaint;
	}
	public List<StatusData> getStatusData() {
		return statusData;
	}
	public void setTotalComplaint(Long totalComplaint) {
		this.totalComplaint = totalComplaint;
	}
	public void setStatusData(List<StatusData> statusData) {
		this.statusData = statusData;
	}
	
	
}


