package com.grievance.dto;

//DTO
public class UpdateRemark {

	private int complaintId;
	private String message;
	
	public UpdateRemark() {
		super();
	}

	public UpdateRemark(int complaintId, String message) {
		super();
		this.complaintId = complaintId;
		this.message = message;
	}

	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "UpdateRemark [complaintId=" + complaintId + ", message=" + message + "]";
	}
	
}
