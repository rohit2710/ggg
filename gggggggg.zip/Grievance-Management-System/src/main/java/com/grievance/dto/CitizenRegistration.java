package com.grievance.dto;

public class CitizenRegistration {
	
	private CitizenDTO citizenDTO;
	private AddressDTO addressDTO;
	
	public CitizenRegistration(){
		
	}
	
	public CitizenRegistration(CitizenDTO citizenDTO, AddressDTO addressDTO) {
		super();
		this.citizenDTO = citizenDTO;
		this.addressDTO = addressDTO;
	}
	public CitizenDTO getCitizenDTO() {
		return citizenDTO;
	}
	public void setCitizenDTO(CitizenDTO citizenDTO) {
		this.citizenDTO = citizenDTO;
	}
	public AddressDTO getAddressDTO() {
		return addressDTO;
	}
	public void setAddressDTO(AddressDTO addressDTO) {
		this.addressDTO = addressDTO;
	}

	@Override
	public String toString() {
		return "CitizenRegistration [citizenDTO=" + citizenDTO + ", addressDTO=" + addressDTO + "]";
	}
	
	
	
	
}
