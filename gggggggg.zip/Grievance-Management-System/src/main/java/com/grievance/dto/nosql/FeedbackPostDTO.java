package com.grievance.dto.nosql;

public class FeedbackPostDTO {
	private Integer likes;
	private Integer dislikes;
	private Integer postComments;
	private Integer ratings;
	
	public FeedbackPostDTO() {
		super();
	}

	public FeedbackPostDTO(Integer likes, Integer dislikes, Integer postComments, Integer ratings) {
		super();
		this.likes = likes;
		this.dislikes = dislikes;
		this.postComments = postComments;
		this.ratings = ratings;
	}

	public Integer getLikes() {
		return likes;
	}

	public void setLikes(Integer likes) {
		this.likes = likes;
	}

	public Integer getDislikes() {
		return dislikes;
	}

	public void setDislikes(Integer dislikes) {
		this.dislikes = dislikes;
	}

	public Integer getPostComments() {
		return postComments;
	}

	public void setPostComments(Integer postComments) {
		this.postComments = postComments;
	}

	public Integer getRatings() {
		return ratings;
	}

	public void setRatings(Integer ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "FeedbackPostDTO [likes=" + likes + ", dislikes=" + dislikes + ", postComments=" + postComments
				+ ", ratings=" + ratings + "]";
	}
}