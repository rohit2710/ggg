package com.grievance.dto;

import java.io.Serializable;
import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.grievance.entity.Department;

public class ComplaintDTO {

	private Integer complaintId;
	private String complaintMessage;
	private Instant createdAt;
	private String complaintStatus;
	private String documentPath;
	
	private ShowCitizenDTO showCitizen;
	private AddressDTO address;
	private String chatId;
//	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
//	private Department department;
	
	public ComplaintDTO() {
		super();
	}

public ComplaintDTO(Integer complaintId, String complaintMessage, Instant createdAt, String complaintStatus,
		String documentPath, ShowCitizenDTO showCitizen, AddressDTO address) {
	super();
	this.complaintId = complaintId;
	this.complaintMessage = complaintMessage;
	this.createdAt = createdAt;
	this.complaintStatus = complaintStatus;
	this.documentPath = documentPath;
	this.showCitizen = showCitizen;
	this.address = address;
}

public Integer getComplaintId() {
	return complaintId;
}

public void setComplaintId(Integer complaintId) {
	this.complaintId = complaintId;
}

public String getComplaintMessage() {
	return complaintMessage;
}

public void setComplaintMessage(String complaintMessage) {
	this.complaintMessage = complaintMessage;
}

public Instant getCreatedAt() {
	return createdAt;
}

public void setCreatedAt(Instant createdAt) {
	this.createdAt = createdAt;
}

public String getComplaintStatus() {
	return complaintStatus;
}

public void setComplaintStatus(String complaintStatus) {
	this.complaintStatus = complaintStatus;
}

public String getDocumentPath() {
	return documentPath;
}

public void setDocumentPath(String documentPath) {
	this.documentPath = documentPath;
}

public ShowCitizenDTO getShowCitizen() {
	return showCitizen;
}

public void setShowCitizen(ShowCitizenDTO showCitizen) {
	this.showCitizen = showCitizen;
}

public AddressDTO getAddress() {
	return address;
}

public void setAddress(AddressDTO address) {
	this.address = address;
}

public String getChatId() {
	return chatId;
}

public void setChatId(String chatId) {
	this.chatId = chatId;
}

@Override
public String toString() {
	return "ComplaintDTO [complaintId=" + complaintId + ", complaintMessage=" + complaintMessage + ", createdAt="
			+ createdAt + ", complaintStatus=" + complaintStatus + ", documentPath=" + documentPath + ", showCitizen="
			+ showCitizen + ", address=" + address + ", chatId=" + chatId + "]";
}


}
