package com.grievance.dto;

public class AddressDTO {
	
	private String houseNo;
	private String landmark;
	private String pincode;
	
	public AddressDTO() {
		super();
	}
	
	public AddressDTO(String houseNo, String landmark, String pincode) {
		super();
		this.houseNo = houseNo;
		this.landmark = landmark;
		this.pincode = pincode;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "AddressDTO [houseNo=" + houseNo + ", landmark=" + landmark + ", pincode=" + pincode + "]";
	}
	
}
