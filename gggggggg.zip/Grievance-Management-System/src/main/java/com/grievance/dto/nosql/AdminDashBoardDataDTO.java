package com.grievance.dto.nosql;

public class AdminDashBoardDataDTO {
  
}
