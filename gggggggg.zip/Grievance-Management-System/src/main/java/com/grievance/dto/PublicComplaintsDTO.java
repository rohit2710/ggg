package com.grievance.dto;

import java.time.Instant;

public class PublicComplaintsDTO {
	
	private Integer complaintId;
	private String complaintMessage;
	private Instant createdAt;
	private String documentPath;
	private String feedbackPostId;
	private String citizenName;
	private String departmentName;
	
	public PublicComplaintsDTO() {
		super();
	}

	public PublicComplaintsDTO(Integer complaintId, String complaintMessage, Instant createdAt, String documentPath,
			String feedbackPostId, String citizenName, String departmentName) {
		super();
		this.complaintId = complaintId;
		this.complaintMessage = complaintMessage;
		this.createdAt = createdAt;
		this.documentPath = documentPath;
		this.feedbackPostId = feedbackPostId;
		this.citizenName = citizenName;
		this.departmentName = departmentName;
	}

	public Integer getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintMessage() {
		return complaintMessage;
	}

	public void setComplaintMessage(String complaintMessage) {
		this.complaintMessage = complaintMessage;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public String getFeedbackPostId() {
		return feedbackPostId;
	}

	public void setFeedbackPostId(String feedbackPostId) {
		this.feedbackPostId = feedbackPostId;
	}

	public String getCitizenName() {
		return citizenName;
	}

	public void setCitizenName(String citizenName) {
		this.citizenName = citizenName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	@Override
	public String toString() {
		return "PublicComplaintsDTO [complaintId=" + complaintId + ", complaintMessage=" + complaintMessage
				+ ", createdAt=" + createdAt + ", documentPath=" + documentPath + ", feedbackPostId=" + feedbackPostId
				+ ", citizenName=" + citizenName + ", departmentName=" + departmentName + "]";
	}

}
