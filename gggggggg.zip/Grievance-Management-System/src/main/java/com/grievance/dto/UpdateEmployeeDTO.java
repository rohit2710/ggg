package com.grievance.dto;

public class UpdateEmployeeDTO {
	private String email;
	private String mobileNo;

	public UpdateEmployeeDTO() {
		super();
	}

	public UpdateEmployeeDTO(String email, String mobileNo) {
		super();
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
}
