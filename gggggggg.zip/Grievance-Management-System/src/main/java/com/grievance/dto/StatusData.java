package com.grievance.dto;

public class  StatusData{
	private String Status;
	private Long count;
	
	public StatusData() {
		super();
	}
	public StatusData(String status, Long count) {
		super();
		Status = status;
		this.count = count;
	}
	public String getStatus() {
		return Status;
	}
	public Long getCount() {
		return count;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	
	
}