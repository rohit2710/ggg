package com.grievance.dto;

public class CitizenDTO {
	private String name;
	private String email;
	private String password;
	private String mobileNo;
	private String aadharNo;
	
	public CitizenDTO() {
		super();
	}

	public CitizenDTO(String name, String email, String password, String mobileNo, String aadharNo) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobileNo = mobileNo;
		this.aadharNo = aadharNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	@Override
	public String toString() {
		return "CitizenDTO [name=" + name + ", email=" + email + ", password=" + password + ", mobileNo=" + mobileNo
				+ ", aadharNo=" + aadharNo + "]";
	}
	
}
