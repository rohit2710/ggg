package com.grievance.dto;

import java.io.Serializable;
import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Department;

public class CitizenComplaintDTO implements Serializable{
	private Integer complaintId;
	private String complaintMessage;
	private Instant createdAt;
	private Instant resolvedAt;
	private String complaintStatus;
	private String documentPath;
	private boolean reminder;
	private String chatId;
	private String feedbackPostId;
//	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private ShowCitizenDTO citizenDTO;
	private String departmentName;
//	 @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private AddressDTO addressDTO;
	private AddressDTO address;
	public CitizenComplaintDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CitizenComplaintDTO(Integer complaintId, String complaintMessage, Instant createdAt, Instant resolvedAt,
			String complaintStatus, String documentPath, boolean reminder, String chatId, String feedbackPostId,
			ShowCitizenDTO citizenDTO, String departmentName, AddressDTO addressDTO, AddressDTO address) {
		super();
		this.complaintId = complaintId;
		this.complaintMessage = complaintMessage;
		this.createdAt = createdAt;
		this.resolvedAt = resolvedAt;
		this.complaintStatus = complaintStatus;
		this.documentPath = documentPath;
		this.reminder = reminder;
		this.chatId = chatId;
		this.feedbackPostId = feedbackPostId;
		this.citizenDTO = citizenDTO;
		this.departmentName = departmentName;
		this.addressDTO = addressDTO;
		this.address = address;
	}



	public Integer getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}
	public String getComplaintMessage() {
		return complaintMessage;
	}
	public void setComplaintMessage(String complaintMessage) {
		this.complaintMessage = complaintMessage;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getResolvedAt() {
		return resolvedAt;
	}
	public void setResolvedAt(Instant resolvedAt) {
		this.resolvedAt = resolvedAt;
	}
	public String getComplaintStatus() {
		return complaintStatus;
	}
	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}
	public String getDocumentPath() {
		return documentPath;
	}
	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}
	public boolean isReminder() {
		return reminder;
	}
	public void setReminder(boolean reminder) {
		this.reminder = reminder;
	}
	public ShowCitizenDTO getCitizenDTO() {
		return citizenDTO;
	}
	public void setCitizenDTO(ShowCitizenDTO citizenDTO) {
		this.citizenDTO = citizenDTO;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public AddressDTO getAddressDTO() {
		return addressDTO;
	}
	public void setAddressDTO(AddressDTO addressDTO) {
		this.addressDTO = addressDTO;
	}
	public AddressDTO getAddress() {
		return address;
	}
	public void setAddress(AddressDTO address) {
		this.address = address;
	}
	
	
	public String getChatId() {
		return chatId;
	}
	public String getFeedbackPostId() {
		return feedbackPostId;
	}
	public void setChatId(String chatId) {
		this.chatId = chatId;
	}
	public void setFeedbackPostId(String feedbackPostId) {
		this.feedbackPostId = feedbackPostId;
	}

	@Override
	public String toString() {
		return "CitizenComplaintDTO [complaintId=" + complaintId + ", complaintMessage=" + complaintMessage
				+ ", createdAt=" + createdAt + ", resolvedAt=" + resolvedAt + ", complaintStatus=" + complaintStatus
				+ ", documentPath=" + documentPath + ", reminder=" + reminder + ", chatId=" + chatId
				+ ", feedbackPostId=" + feedbackPostId + ", citizenDTO=" + citizenDTO + ", departmentName="
				+ departmentName + ", addressDTO=" + addressDTO + ", address=" + address + "]";
	}
	
	
	
}
