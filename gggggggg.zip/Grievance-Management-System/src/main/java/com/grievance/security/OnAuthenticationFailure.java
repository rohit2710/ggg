package com.grievance.security;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;

import com.grievance.service.ICitizenService;
import com.grievance.service.IDepartmentService;



@Component
public class OnAuthenticationFailure {
	
	@Autowired
	IDepartmentService departmentService;
	
	@Autowired
	ICitizenService citizenService;
	
	@EventListener
	public void onAuthenticationFailure(AuthenticationFailureBadCredentialsEvent event) {
		String email =(String)event.getAuthentication().getPrincipal();
		
		if(this.departmentService.incrementFailedAttempts(email)!= true) {
			this.citizenService.incrementFailedAttempts(email);
		}
	}
}