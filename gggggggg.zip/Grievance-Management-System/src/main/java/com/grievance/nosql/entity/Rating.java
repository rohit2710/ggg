package com.grievance.nosql.entity;

public class Rating {

	private Integer citizenId;
	private Integer ratings;

	public Rating() {
		super();
	}

	public Rating(Integer citizenId, Integer ratings) {
		super();
		this.citizenId = citizenId;
		this.ratings = ratings;
	}

	public Integer getCitizenId() {
		return citizenId;
	}

	public void setCitizenId(Integer citizenId) {
		this.citizenId = citizenId;
	}

	public Integer getRatings() {
		return ratings;
	}

	public void setRatings(Integer ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "Rating [citizenId=" + citizenId + ", ratings=" + ratings + "]";
	}

}
