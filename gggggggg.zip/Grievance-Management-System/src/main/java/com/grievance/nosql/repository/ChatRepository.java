package com.grievance.nosql.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.grievance.nosql.entity.Chat;

@Repository
public interface ChatRepository extends MongoRepository<Chat, String> {
      Optional<Chat> findById(String id);
}
