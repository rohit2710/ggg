package com.grievance.nosql.entity;

import java.util.List;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("chat")
public class Chat {

	@Id
	private String id;

	private Integer citizenId;

	private Integer departmentId;

	private List<Messages> messages;

	// user this for add Message
	public void addMessage(Messages  message) {
	     this.messages.add(message);
	}

	public Chat() {
		super();
	}

	public Chat(String id, Integer citizenId, Integer employeeId, List<Messages> messages, String documentPath) {
		super();
		this.id = id;
		this.citizenId = citizenId;
		this.departmentId = employeeId;
		this.messages = messages;

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getCitizenId() {
		return citizenId;
	}

	public void setCitizenId(Integer citizenId) {
		this.citizenId = citizenId;
	}


	public List<Messages> getMessages() {
		return messages;
	}

	public void setMessages(List<Messages> messages) {
		this.messages = messages;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	
	

}
