package com.grievance.nosql.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "postFeedback")
public class PostFeedback {
	@Id
	private String id;

	private List<PostComment> postComments;

	private List<Integer> likes;

	private List<Integer> dislikes;

	private List<Rating> ratings;

	public void addPostComments(PostComment postComment) {
		this.postComments.add(postComment);
	}

	public void like(Integer userId) {
		if (this.dislikes.contains(userId)) {
             this.dislikes.remove(userId);
             this.likes.add(userId);
             return;
		} else if (!this.likes.contains(userId)) {
			this.likes.add(userId);
		}
	}

	public void disLike(Integer userId) {
		if (this.likes.contains(userId)) {
            this.likes.remove(userId);
            this.dislikes.add(userId);
            return;
		} else if (!this.dislikes.contains(userId)) {
			this.dislikes.add(userId);
		}
	}

	public PostFeedback() {

	}

	public PostFeedback(String id, List<PostComment> postComments, List<Integer> likes, List<Integer> dislikes,
			List<Rating> ratings) {
		super();
		this.id = id;
		this.postComments = postComments;
		this.likes = likes;
		this.dislikes = dislikes;
		this.ratings = ratings;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<PostComment> getPostComments() {
		return postComments;
	}

	public void setPostComments(List<PostComment> postComments) {
		this.postComments = postComments;
	}

	public List<Integer> getLikes() {
		return likes;
	}

	public void setLikes(List<Integer> likes) {
		this.likes = likes;
	}

	public List<Integer> getDislikes() {
		return dislikes;
	}

	public void setDislikes(List<Integer> dislikes) {
		this.dislikes = dislikes;
	}

	public List<Rating> getRatings() {
		return ratings;
	}

	public void setRatings(List<Rating> ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "PostFeedback [id=" + id + ", postComments=" + postComments + ", likes=" + likes + ", dislikes="
				+ dislikes + ", ratings=" + ratings + "]";
	}

}
