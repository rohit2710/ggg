package com.grievance.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grievance.entity.Department;
import com.grievance.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	public Optional<Employee> findByDepartment(Department department);
	
//	@Query("SELECT e FROM Employee e join fetch e.department")
//	public List<Employee> findAllEmployee();

	public Employee findByEmail(String email);

	@Query("SELECT e FROM  Employee e WHERE e.isActived = 0 AND e.loginAttempts = 3")
	public List<Employee> getAllDeactiveEmloyee();
	
	@Query("SELECT e FROM  Employee e WHERE e.role!= 'ADMIN' ")
	public List<Employee> getAllEmployees();

}
