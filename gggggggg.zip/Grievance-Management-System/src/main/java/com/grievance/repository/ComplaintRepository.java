package com.grievance.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import java.lang.String;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Integer>{

	public List<Complaint> findByCitizen(Citizen citizen);
	
//	@Query("SELECT c from Complaint c join fetch c.address  join fetch c.department join fetch c.citizen ")
	List<Complaint> findByDepartment(Department department);
	List<Complaint> findByDepartment(Department department,Pageable pageable);

	
	@Query("SELECT c from Complaint c join fetch c.address  join fetch c.department join fetch c.citizen ")
	public List<Complaint> findAllComplaints();

//	@Query("select c from Complaint c join fetch c.department where c.department.departmentId is NULL")
//	public List<Complaint> findAllComplaintWithNoDepartment();
	
    public Long countByComplaintStatus(String complaintStatus);
    
    public Long countByDepartment(Department department);
      
    public Long countByDepartmentAndComplaintStatus(Department department,String complaintStatus);
    
    List<Complaint> findByComplaintStatus(String complaintstatus, Pageable pageable);
    
    List<Complaint> findByComplaintStatusAndDepartment(String complaintStatus,Department department, Pageable pageable);

    
    

    
}
