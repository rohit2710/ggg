package com.grievance.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.aggregation.ArithmeticOperators.Add;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.grievance.dto.AddressDTO;
import com.grievance.dto.CitizenComplaintDTO;
import com.grievance.dto.CitizenDTO;
import com.grievance.dto.CitizenRegistration;
import com.grievance.dto.ComplaintAddress;
import com.grievance.dto.ComplaintRegisterDTO;
import com.grievance.dto.ResetPassword;
import com.grievance.dto.ShowCitizenDTO;
import com.grievance.dto.UpdateRemark;
import com.grievance.dto.PublicComplaintsDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Auth;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.repository.PostFeedbackRepository;
import com.grievance.repository.CitizenRepository;
import com.grievance.service.CitizenService;
import com.grievance.service.ICitizenService;
import com.grievance.service.IEmailService;

@RestController
@RequestMapping("/api/citizen")
@CrossOrigin(origins = "*")
public class CitizenController {

	//this commented code has been pasted in Authentication Controller

	//	@Autowired
	//	private CitizenService citizenService;
	//	
	//	@Autowired
	//	private ModelMapper modelMapper;
	//	
	//	@Autowired
	//	private IEmailService iEmailService;
	//	
	//	@PostMapping(value = "/register")
	//	public ResponseEntity<Citizen> registerCitizen(@RequestBody CitizenRegistration citizenRegistration) throws MessagingException{
	//		modelMapper.getConfiguration()
	//		.setMatchingStrategy(MatchingStrategies.LOOSE);
	//		Citizen citizen = modelMapper.map(citizenRegistration.getCitizenDTO() , Citizen.class);
	//		Address address = modelMapper.map(citizenRegistration.getAddressDTO(), Address.class);
	//		citizen = citizenService.registerCitizen(citizen, address);
	//		return ResponseEntity.status(HttpStatus.OK).body(citizen);
	//	}
	//	
	//	public int generateOtp() {
	//		return (int) (Math.round(Math.random()*999999));
	//	}
	//	
	//	@GetMapping(value = "/authentication/{citizenId}")
	//	public String sendOTP(@PathVariable int citizenId) throws MessagingException {
	//		int otp;
	//		otp = generateOtp();
	//		Citizen citizen = citizenService.getUserById(citizenId);
	//		Auth auth = iEmailService.addOTP(citizenId, otp);
	//		String text =  "Your Account Activation OTP is "+otp;
	//		if(auth !=null) {
	//			return iEmailService.sendEmail(citizen.getEmail(), "Account Activation OTP", text);
	//		}
	//		else {
	//			return "try again";
	//		}
	//	}

	private static final Logger logger = LogManager.getLogger(CitizenController.class);

	@Autowired
	private ModelMapper modelMapper; //modal mapper to map entity with the DTO (This reduces the use of setter)

	@Autowired
	private ICitizenService citizenService;
	
	@Autowired
	PostFeedbackRepository feedbackRepository;

	// this method registers complaint given by logged in user.
	@PostMapping(value = "/complaint/{citizenId}")
	public ResponseEntity<Complaint> registerComplaint(@RequestBody ComplaintRegisterDTO complaintDto, 
			@PathVariable int citizenId) throws MessagingException{
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT); //model mapper used to map two classes STRICT
		Complaint complaint=modelMapper.map(complaintDto,Complaint.class);
		complaint=citizenService.registerComplaint(complaint, citizenId,
				complaintDto.getDepartmentId(),complaintDto.getAddressId());
		logger.info("complaint registered successfully against citizenId : "+citizenId);
		return ResponseEntity.status(HttpStatus.OK).body(complaint);
	}

	// this method will populate complaints which are registered by logged in user.
	@GetMapping(value = "/complaints/{citizenId}")
	public ResponseEntity<List<CitizenComplaintDTO>>getAllComplaints(@PathVariable int citizenId){
		List<Complaint> complaints = citizenService.getAllComplaintsOfCitizen(citizenId);
		List<CitizenComplaintDTO> complaintsDTO=new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.LOOSE);//model mapper used to map two classes LOOSE
		for(Complaint complaint : complaints) {
			CitizenComplaintDTO complaintDTO=modelMapper.map(complaint,CitizenComplaintDTO.class);
			complaintDTO.setAddressDTO(modelMapper.map(complaint.getAddress(), AddressDTO.class));	
			complaintDTO.setDepartmentName(complaint.getDepartment().getDepartmentName());
			complaintDTO.setCitizenDTO(modelMapper.map(complaint.getCitizen(), ShowCitizenDTO.class));
			complaintsDTO.add(complaintDTO);
		}
		return ResponseEntity.status(HttpStatus.OK).body(complaintsDTO);
	}

	// this will send reminder in case if citizen is not satisfied with resolution
	@PutMapping(value = "/reminder/{complaintId}")
	public ResponseEntity<Boolean> sendReminder(@PathVariable int complaintId){
		Complaint complaint = citizenService.sendReminder(complaintId);
		if(complaint!=null) {
			logger.info("Send reminder successfull");
			return ResponseEntity.status(HttpStatus.OK).body(true);
		}else {
			logger.error("Send reminder failed");
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}
	
	//This function will show all the complaints to the logged in citizen to share his review on the complaint
	@GetMapping(value = "/complaints")
	public ResponseEntity<List<PublicComplaintsDTO>> getPublicComplaints(){
		List<Complaint> complaints = citizenService.getAllComplaints();
		List<PublicComplaintsDTO> showPublicComplaintsDTOs = new ArrayList<>();
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		if(complaints !=null) {
			for(Complaint complaint:complaints) {
				PublicComplaintsDTO showPublicComplaintsDTO= modelMapper.map(complaint, PublicComplaintsDTO.class);
				showPublicComplaintsDTO.setCitizenName(complaint.getCitizen().getName());
				showPublicComplaintsDTO.setDepartmentName(complaint.getDepartment().getDepartmentName());
				showPublicComplaintsDTOs.add(showPublicComplaintsDTO);
			}
		}
		if(showPublicComplaintsDTOs != null) {
			return ResponseEntity.status(HttpStatus.OK).body(showPublicComplaintsDTOs);
		}
		return null;	
	}

	// this will reset the password id citizen wants to change it
//	@PutMapping(value = "/password")
//	public ResponseEntity<Boolean> resetPassword(@RequestBody ResetPassword resetPassword){
//		System.out.println("password change");
//		Boolean citizenstatus =  citizenService.resetPassword(resetPassword.getUserId(), resetPassword.getPassword());
//		if(citizen != null) {
//			return ResponseEntity.status(HttpStatus.ACCEPTED).body(true);
//		}else {
//			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
//		}
//	}

	@PutMapping(value = "/citizen/remark")
	public ResponseEntity<Boolean> updateCitizenRemark(@RequestBody UpdateRemark updateRemark){
		Chat chat = citizenService.updateCitizenRemark(updateRemark);
		if(chat !=null)
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(true);
		}
		else
		{
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(false);
		}
	}
	
	//function give all the address citizen has during registering complaint

	@GetMapping("/citizen/{citizenId}/addresses")
	public ResponseEntity<List<ComplaintAddress>> getAllCitizenAddress(@PathVariable int citizenId){
		List<Address> addresses = citizenService.getAllCitizenAddress(citizenId); 
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT);
		List<ComplaintAddress> complaintAddresses = new ArrayList<>();
		for(Address address: addresses) {//mapping Entity to DTO
			ComplaintAddress complaintAddress = modelMapper.map(address, ComplaintAddress.class);
			complaintAddresses.add(complaintAddress);
		}
		return ResponseEntity.status(HttpStatus.OK).body(complaintAddresses);
	}
}
