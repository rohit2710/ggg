package com.grievance.controller;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.grievance.dto.PublicComplaintsDTO;
import com.grievance.dto.nosql.FeedbackPostDTO;
import com.grievance.dto.nosql.GetPostsDetails;
import com.grievance.dto.nosql.PostCounts;
import com.grievance.entity.Complaint;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.Messages;
import com.grievance.nosql.entity.PostComment;
import com.grievance.service.IAppService;

@RestController
@RequestMapping(value ="/app/test")
@CrossOrigin(origins = "*")
public class AppController {

	//this controller is for testing purpose
	@Autowired
	ModelMapper modelMapper;

	@Autowired
	private IAppService iAppService;

	//will take the signle complaint whic hrequest came from front end
	@GetMapping(value = "/getComplaintById/{id}")
	public ResponseEntity<PublicComplaintsDTO> getComplaintById(@PathVariable Integer id){
		modelMapper.getConfiguration()
		.setMatchingStrategy(MatchingStrategies.STRICT); //model mapper used to map two classes STRICT
		Complaint c = this.iAppService.getcomplaintById(id);
		PublicComplaintsDTO publicComplaintsDTO = modelMapper.map(c, PublicComplaintsDTO.class);
		publicComplaintsDTO.setCitizenName(c.getCitizen().getName());
		publicComplaintsDTO.setDepartmentName(c.getDepartment().getDepartmentName());
		return ResponseEntity.status(HttpStatus.OK).body(publicComplaintsDTO);
	}

	//this function will add comment to mongo which is comming from front end
	@PostMapping(value = "addComment/{postFeedbackId}")
	public ResponseEntity<PostComment> addComment(@RequestBody PostComment postComment,@PathVariable String postFeedbackId ){
		postComment = this.iAppService.addComment(postComment, postFeedbackId);
		return ResponseEntity.status(HttpStatus.OK).body(postComment);
	}

	//this function will add like to the post
	@PostMapping(value = "/like/{feedbackPostId}/{userId}")
	public ResponseEntity<PostCounts> like(@PathVariable String feedbackPostId,@PathVariable Integer userId){
		PostCounts postCounts =  this.iAppService.addLike(userId, feedbackPostId);
		return ResponseEntity.status(HttpStatus.OK).body(postCounts);
	}

	///this function will add dislike to the post
	@PostMapping(value = "/dislike/{feedbackPostId}/{userId}")
	public ResponseEntity<PostCounts> dislike(@PathVariable String feedbackPostId,@PathVariable Integer userId){
		PostCounts postCounts = this.iAppService.addDislike(userId, feedbackPostId);
		return ResponseEntity.status(HttpStatus.OK).body(postCounts);
	}

	//this function will load like dislike and comment which belongs to the perticular complaint
	@GetMapping(value = "/loadpost/{feedbackPostId}")
	public ResponseEntity<FeedbackPostDTO> loadPost(@PathVariable String feedbackPostId ){
		FeedbackPostDTO feedbackPostDTO = this.iAppService.loadPost(feedbackPostId);
		return ResponseEntity.status(HttpStatus.OK).body(feedbackPostDTO);
	}

	//this function will add comment to mongo added by citizen
	@PostMapping(value = "/addCommets/{feedbackPostId}")
	public ResponseEntity<PostComment> addCommets(@RequestBody PostComment postCommet
			,@PathVariable String feedbackPostId){
		postCommet = this.iAppService.addCommets(postCommet, feedbackPostId);
		return ResponseEntity.status(HttpStatus.OK).body(postCommet);
	}

	//this function load one perticular complaint feedback
	@GetMapping(value = "/post/{feedbackPostId}")
	public ResponseEntity<GetPostsDetails> loadPostById(@PathVariable String feedbackPostId ){
		GetPostsDetails postDetail = iAppService.loadPostById(feedbackPostId);
		return ResponseEntity.status(HttpStatus.OK).body(postDetail);
	}

	//chatting (this function will load all the previous chat from citizen as well as head comments on complaint)
	@GetMapping(value ="getchat/{chatId}")
	public ResponseEntity<Chat> getAllChatMessages(@PathVariable String chatId ){
		return ResponseEntity.status(HttpStatus.OK).body(this.iAppService.getAllChatMessages(chatId));
	}

	//this function will add chat of either citizen or departmentHead
	@PostMapping(value="addmessage/{chatId}")
	public ResponseEntity<Boolean>  addChatMessage(@RequestBody Messages message
			,@PathVariable String chatId ) {
		return ResponseEntity.status(HttpStatus.OK).body(this.iAppService.addChatMessage(message, chatId));
	}

}


