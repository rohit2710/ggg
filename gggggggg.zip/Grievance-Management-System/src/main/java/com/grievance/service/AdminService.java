package com.grievance.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.grievance.entity.Address;
import com.grievance.entity.Citizen;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.entity.UserRole;
import com.grievance.exception.DepartmentException;
import com.grievance.exception.EmployeeException;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.ComplaintRepository;
import com.grievance.repository.DepartmentRepository;
import com.grievance.repository.EmployeeRepository;

@Service
public class AdminService implements IAdminService {

	@Autowired
	private EmployeeRepository employeeRepository; // employee repo Object

	@Autowired
	private DepartmentRepository departmentRepository; // department repo Object
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private ComplaintRepository complaintRepository;	// complaint repo Object
	
	@Autowired
	private CitizenRepository citizenRepository;
	
	@Autowired
	private IEmailService iEmailService;

	// Employee registration
	@Override
	public Employee registerEmployee(Employee employee, int departmentId) throws MessagingException {
		String email = employee.getEmail();
		String password = employee.getPassword();
		Department department = departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department Not Fount", HttpStatus.NOT_FOUND));
		if (employee != null) {
			employee.setRole(UserRole.DEPARTMENTHEAD.toString());
			employee.setLoginAttempts(0);
			employee.setDepartment(department);
			employee.setPassword(bCryptPasswordEncoder.encode(employee.getPassword()));
			employee = employeeRepository.save(employee); // Hibernate Db save method for citizen
			if(employee != null) {
				String to=employee.getEmail();
				String subject="Login Credentials";
				String text="Your login credentials are\n"+"email: "+email+"\npassword: "+password;
				iEmailService.sendEmail(to, subject, text);
			}
			return employee;
		} else {
			return null;
		}
	}

	// Department registration
	@Override
	public Department registerDepartment(Department department) {
		if (department != null) {
			department = departmentRepository.save(department); // Hibernate Db save method for citizen
			return department;
		} else {
			return null;
		}
	}

	// Get all departments
	@Override
	public List<Department> getAllDepartments() {
		return departmentRepository.findAll();

	}

	// delete department by id
	@Override
	public Boolean deleteDepartment(int departmentId) {
		Department department = departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department Not Fount", HttpStatus.NOT_FOUND));
		departmentRepository.delete(department);
		return Boolean.TRUE;
	}

	//update department
	@Override
	public Department updateDepartment(Department department, int departmentId) {
		Department department1 = departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department not found", HttpStatus.NOT_FOUND));
		department1.setDepartmentName(department.getDepartmentName());
		department1.setDescription(department.getDescription());
		return departmentRepository.save(department1);
	}

	//update Employee
	@Override
	public Boolean updateEmployee(Employee employee, int employeeId, int departmentId) {
		Employee emp = employeeRepository.findById(employeeId).orElseThrow(() -> new EmployeeException("Employee not found", HttpStatus.NOT_FOUND));
		Department department = departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department not found", HttpStatus.NOT_FOUND));
		emp.setEmail(employee.getEmail());
		emp.setMobileNo(employee.getMobileNo());
		emp.setDepartment(department);
		emp = employeeRepository.save(emp);
		return (emp != null);
	}

	//get department using departmentId
	@Override
	public Department getDepartment(int departmentId) {
		Department department = departmentRepository.findById(departmentId).orElseThrow(() -> new EmployeeException("Department not found", HttpStatus.NOT_FOUND));
		return department;

  }
	//get all employees
	@Override
	public List<Employee> getAllEmployee() {
		return employeeRepository.getAllEmployees();
	}

	//get employee using employeeId
	@Override
	public Employee getEmployeeById(int employeeId) {
		Employee emp = employeeRepository.findById(employeeId).orElseThrow(() -> new EmployeeException("Employee not found", HttpStatus.NOT_FOUND));
		return emp;
	}

	//get all complaints from database
	@Override
	public Page<Complaint> getAllComplaints(Pageable pageable) {
		Page<Complaint> complaints=complaintRepository.findAll(pageable);
		return complaints;
	}

	@Override
	public List<Complaint> getAllComplaintWithNoDepartment() {
		return complaintRepository.findAll();
	}

	//this will return complaint count using complaint status
	@Override
	public Long getComplaintCount(String complaintStatus) {
		return this.complaintRepository.countByComplaintStatus(complaintStatus);
	}

	@Override
	public Long getComplaintCountByDeptAndStatus(String departmentName, String complaintStatus) {
		   Department department = this.departmentRepository.findByDepartmentName(departmentName);
		return this.complaintRepository.countByDepartmentAndComplaintStatus(department, complaintStatus);
	}

	//this will return list of deactivate citizens
	@Override
	public List<Citizen> getAllDeactiveCitizen() {
		return citizenRepository.getAllDeactiveCitizen();
	}

	//this will return list of deactivate employees
	@Override
	public List<Employee> getAllDeactiveEmloyee() {
		return employeeRepository.getAllDeactiveEmloyee();
	}

	//this will activate account
	@Override
	public Boolean ActiveAccount(String email) {
		Citizen citizen = citizenRepository.findByEmail(email);
		if(citizen !=null) {
			citizen.setActived(true);
			citizen.setLoginAttempts(0);
			citizenRepository.save(citizen);
			return true;
		}
		else {
			Employee employee = employeeRepository.findByEmail(email);
			if(employee != null) {
				employee.setActived(true);
				employee.setLoginAttempts(0);
				employeeRepository.save(employee);
				return true;
			}else {
				return false;
			}
		}

	}

	//this will return list of complaints using department name
	public List<Complaint> getComplaintByDepartmentName(String departmentName) {
		Department department = departmentRepository.findByDepartmentName(departmentName);
		List<Complaint> complaints = complaintRepository.findByDepartment(department);
		return complaints;
	}

}
