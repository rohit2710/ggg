package com.grievance.service;


import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.grievance.entity.Auth;
import com.grievance.entity.Citizen;
import com.grievance.entity.Employee;
import com.grievance.exception.EmployeeException;
import com.grievance.repository.AuthRepository;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.EmployeeRepository;
import com.mongodb.lang.NonNull;

@Service
@Transactional
public class EmailService implements IEmailService {

	@Autowired
	private CitizenRepository citizenRepository;

	@Autowired
	private AuthRepository authRepository;
	
	@Autowired
	private EmployeeRepository employeerepository;

	@Value("${from}")
	private String from;
	@Value("${password}")
	private String password;
	@Value("${host}")
	private String host;
	@Value("${port}")
	private String port;

	//This function will be called when ever there is requirement of sending  the email to user
	@Override
	public String sendEmail(String to, String subject, String text) throws MessagingException{
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", this.host);
		props.put("mail.smtp.port", this.port);

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(to));
		message.setSubject(subject);
		message.setText(text);
		Transport.send(message);
		return "message send successfully";
	}

	//this function will store the OTp in database
	@Override
	public Auth addOTP(int userId) throws MessagingException {
		Citizen citizen = citizenRepository.findById(userId).orElse(null); 
		int otp = this.generateOtp();
		String text =  "Your Account Activation OTP is "+otp;
		String subject =  "Account Activation OTP ";
		Auth auth = new Auth();
		auth.setOtp(otp);
		if(citizen != null) {
			this.sendEmail(citizen.getEmail(), subject, text);
			auth.setCitizen(citizen);
			authRepository.save(auth);
			return auth;
		}else {
			Employee employee = employeerepository.findById(userId).orElseThrow(() -> new EmployeeException("Employee Not found", HttpStatus.NOT_FOUND));
			if(employee !=null) {
				this.sendEmail(employee.getEmail(), subject, text);
				auth.setEmployee(employee);
				authRepository.save(auth);
			}
		}
		return null;
	}
	
	//This will generate OTP
	@Override
	public int generateOtp() {
		return (int) (Math.round(Math.random()*999999));
	}

	@Override
	public Boolean sendOtpForAccountActivation(Citizen citizen) throws MessagingException {
		Auth auth = new Auth();
//		citizen = this.citizenRepository.findByEmail(citizen.getEmail());
		int otp = this.generateOtp();
		this.authRepository.deleteByCitizen(citizen);
		String text =  "Your Account Activation OTP is "+otp;
		String subject =  "Account Activation OTP ";
		auth.setOtp(otp);
		auth.setCitizen(citizen);
		auth = authRepository.save(auth);
		if(auth !=null) {
			this.sendEmail(citizen.getEmail(), subject, text);
			return true;
		}
		else {
			return false;
		}
	}
}
