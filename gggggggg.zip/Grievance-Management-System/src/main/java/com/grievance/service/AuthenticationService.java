package com.grievance.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.grievance.dto.UpdatePassword;
import com.grievance.dto.ValidateOtpDTO;
import com.grievance.entity.Address;
import com.grievance.entity.Auth;
import com.grievance.entity.Citizen;
import com.grievance.entity.Employee;
import com.grievance.entity.UserRole;
import com.grievance.exception.CitizenException;
import com.grievance.repository.AddressRepository;
import com.grievance.repository.AuthRepository;
import com.grievance.repository.CitizenRepository;
import com.grievance.repository.EmployeeRepository;

@Service
public class AuthenticationService implements IAuthenticationService {

	@Autowired
	private CitizenRepository citizenRepository; //citizen repo Object

	@Autowired
	private AddressRepository addressRepository; // address repository to store address of the citizen;

	@Autowired
	private AuthRepository authRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	//Citizen registration
	@Override
	public Citizen registerCitizen(Citizen citizen, Address address)  {
		if(citizen != null && address != null) {
			citizen.setRole(UserRole.CITIZEN.toString());
			citizen.setLoginAttempts(0);
			citizen.setActived(false);
			citizen.setPassword(bCryptPasswordEncoder.encode(citizen.getPassword()));
			citizen = citizenRepository.save(citizen); //Hybernate Db save method for citizen
			registerAddress(citizen, address);
			return citizen;
		}
		else {
			return null;
		}
	}

	//Citizen Address registration
	@Override
	public void registerAddress(Citizen citizen, Address address) {
		address.setCitizen(citizen);
		addressRepository.save(address); //Hybernate Db save method for address
	}

	//validate email entered by the citizen
	@Override
	public Citizen validateEmail(String email) {
		return citizenRepository.findByEmail(email);
	}

	//OTP validation (recieved on the email)
	@Override
	public Boolean validateOtp(ValidateOtpDTO validateOtpDTO) {
		Citizen citizen = citizenRepository.findByEmail(validateOtpDTO.getEmail());
		Auth auth = new Auth();
		if(citizen !=null) {
			 auth = authRepository.findByCitizenAndOtp(citizen, validateOtpDTO.getOtp()).orElseThrow(() -> new CitizenException("no use found"));
		}else
		{
			Employee employee = employeeRepository.findByEmail(validateOtpDTO.getEmail());
			auth = authRepository.findByEmployee(employee);
		}
		if(auth.getOtp().equals(validateOtpDTO.getOtp()))
		{
			authRepository.deleteById(auth.getAuthId());
			return true;
		}else {
			return false;
		}
	}

	//Reseting password
	@Override
	public Boolean updatePassword(UpdatePassword updatePassword) {
		Citizen citizen = citizenRepository.findByEmail(updatePassword.getEmail());
       if(citizen != null) {
    	   citizen.setPassword(this.bCryptPasswordEncoder.encode(updatePassword.getNewPassword()));
    	   this.citizenRepository.save(citizen);
       }else {
    	      Employee employee = this.employeeRepository.findByEmail(updatePassword.getEmail());
           employee.setPassword(this.bCryptPasswordEncoder.encode(updatePassword.getNewPassword()));
           this.employeeRepository.save(employee);
       } 
		
		return true;
	}

	//this will return employee using email
	@Override
	public Employee getEmployeeByEmail(String email) {
		return employeeRepository.findByEmail(email);
	}

	//this will return citizen using email
	@Override
	public Citizen getCitizenByEmail(String email) {
		return citizenRepository.findByEmail(email);
	}

	@Override
	public Employee validateEmployeeEmail(String email) {
		return employeeRepository.findByEmail(email);
	}

	@Override
	public Boolean activateAccount(ValidateOtpDTO validateOtpDTO) {
		Citizen citizen = citizenRepository.findByEmail(validateOtpDTO.getEmail());
		Auth auth = authRepository.findByCitizenAndOtp(citizen, validateOtpDTO.getOtp()).orElseThrow(() -> new CitizenException("no citizen "));
		citizen.setActived(true);
		if(auth !=null)
		{
			return true;
		}
		return false;
	}

}
