package com.grievance.service;

import org.springframework.web.bind.annotation.PathVariable;

import com.grievance.dto.nosql.FeedbackPostDTO;
import com.grievance.dto.nosql.GetPostsDetails;
import com.grievance.dto.nosql.PostCounts;
import com.grievance.entity.Complaint;
import com.grievance.nosql.entity.Chat;
import com.grievance.nosql.entity.Messages;
import com.grievance.nosql.entity.PostComment;
import com.grievance.nosql.entity.PostFeedback;

public interface IAppService {
	public Complaint getcomplaintById(int complaintId);
	public PostComment addComment(PostComment postComment, String postFeedbackId);
	public PostCounts addLike(Integer userId, String feedbackPostId);
	public PostCounts addDislike(Integer userId, String feedbackPostId);
	public FeedbackPostDTO loadPost(String feedbackPostId);
	public PostComment addCommets(PostComment postCommet, String feedbackPostId);
	public GetPostsDetails loadPostById(String feedbackPostId);
	public Chat getAllChatMessages(String chatId);
	public Boolean addChatMessage(Messages message, String chatId);
	
}
