package com.grievance.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.grievance.dto.GraphDataDTO;
import com.grievance.dto.StatusData;
import com.grievance.entity.Complaint;
import com.grievance.entity.Department;
import com.grievance.entity.Employee;
import com.grievance.exception.DepartmentException;
import com.grievance.exception.EmployeeException;
import com.grievance.repository.ComplaintRepository;
import com.grievance.repository.DepartmentRepository;
import com.grievance.repository.EmployeeRepository;

@Service
public class  ComplaintSevice implements IComplaintService {

	@Autowired
	private ComplaintRepository complaintRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired EmployeeRepository employeeRepository;
	
	@Override
	public Long getTotalComplaintsCount() {
		return this.complaintRepository.count();
	}

	@Override
	public Long getCountByDepartmentAndStatus(Integer departmentId,String complaintStatus) {
		 Department department = this.departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department not found"));
		return this.complaintRepository.countByDepartmentAndComplaintStatus(department, complaintStatus);
	}

	//this will return complaint count using status
	@Override
	public Long getComplaintCountByStatus(String complaintStatus) {
		return this.complaintRepository.countByComplaintStatus(complaintStatus);
	}
	
	public GraphDataDTO getDataByDepartment(Integer departmentId) {
		String[] statusArray = {"RESOLVED", "REOPENED", "PENDING"};
		GraphDataDTO dataDTO = new GraphDataDTO();
		 Department department = this.departmentRepository.findById(departmentId).orElseThrow(() -> new DepartmentException("Department not found"));
		 dataDTO.setTotalComplaint(this.complaintRepository.countByDepartment(department));
		dataDTO.setStatusData(new ArrayList<>());
		for (String status : statusArray) {
			dataDTO.getStatusData().add(new StatusData(status, this.complaintRepository.countByDepartmentAndComplaintStatus(department, status)));
		}
		return dataDTO;
	}
	
	public GraphDataDTO getAllData() {
		String[] statusArray = {"RESOLVED", "REOPENED", "PENDING"};
		GraphDataDTO dataDTO = new GraphDataDTO();
		 dataDTO.setTotalComplaint(this.complaintRepository.count());
		dataDTO.setStatusData(new ArrayList<>());
		for (String status : statusArray) {
			dataDTO.getStatusData().add(new StatusData(status, this.complaintRepository.countByComplaintStatus(status)));
		}
		return dataDTO;
	}
	
	public GraphDataDTO getDataByEmployeeId(Integer employeeId) {
		String[] statusArray = {"RESOLVED", "REOPENED", "PENDING"};
		GraphDataDTO dataDTO = new GraphDataDTO();
	     Employee employee = this.employeeRepository.findById(employeeId).orElseThrow(() -> new EmployeeException("employee not found"));
		 return this.getDataByDepartment(employee.getDepartment().getDepartmentId());
	}
	
	//this will return list of complaints using employeeId
	public List<Complaint> getComplaintsOfDepartmentByEmployeeId(int departmentId,Pageable pageable) {
		Department department = departmentRepository.findByDepartmentId(departmentId);
		List<Complaint> complaints = complaintRepository.findByDepartment(department,pageable);
		return complaints;
	}
	
	

	

	
	
}
